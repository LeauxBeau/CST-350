﻿CREATE TABLE [dbo].[Products]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NCHAR(50) NULL, 
    [Price] DECIMAL NULL, 
    [Description] NVARCHAR(300) NULL
)
