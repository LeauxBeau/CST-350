﻿using ASPCoreFirstApp.Models;

namespace ASPCoreFirstApp.Services
{
    public class CarDataRepo : IProductDataService
    {
        public List<ProductModel> AllProducts()
        {
            throw new NotImplementedException();
        }

        public bool Delete(ProductModel product)
        {
            throw new NotImplementedException();
        }

        public ProductModel GetProductById(int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(ProductModel product)
        {
            throw new NotImplementedException();
        }

        public List<ProductModel> SearchProducts(string searchTerm)
        {
            throw new NotImplementedException();
        }

        public int Update(ProductModel product)
        {
            throw new NotImplementedException();
        }
    }
}
